
Create database project;
use project;
DROP DATABASE project;

CREATE TABLE Employees (
    employee_id INT PRIMARY KEY,
    name VARCHAR(255),
    department_id INT,
    position_id INT,
    salary_id INT
);
-- -----------------------------------------------------------
-- 2) Department (department_id, department_name)

CREATE TABLE Department (
    department_id INT PRIMARY KEY,
    department_name VARCHAR(255)
);
-- -----------------------------------------------------------
-- 3) Positions (position_id, position_title)

CREATE TABLE Positions (
    position_id INT PRIMARY KEY,
    position_title VARCHAR(255)
);
-- -----------------------------------------------------------
-- 4) Salaries (salary_id, employee_id, amount, effective_date)

CREATE TABLE Salaries (
    salary_id INT PRIMARY KEY,
    employee_id INT,
    amount DECIMAL(10, 2),
    effective_date DATE
);
-- ------------------------------------------------------------
-- 5) Attendance (attendance_id, employee_id, date, time_in, time_out)

CREATE TABLE Attendance (
    attendance_id INT PRIMARY KEY,
    employee_id INT,
    date DATE,
    time_in TIME,
    time_out TIME
);
-- ------------------------------------------------------------
-- 6) Projects (project_id, project_name, department_id)

CREATE TABLE Projects (
    project_id INT PRIMARY KEY,
    project_name VARCHAR(255),
    department_id INT
);
-- ------------------------------------------------------------
-- 7) LeaveRequests (request_id, employee_id, start_date, end_date, status)

CREATE TABLE LeaveRequests (
    request_id INT PRIMARY KEY,
    employee_id INT,
    start_date DATE,
    end_date DATE,
    status VARCHAR(50)
);
-- -------------------------------------------------------------
-- 8) Shifts (shift_id, employee_id, shift_type, start_time, end_time)

CREATE TABLE Shifts (
    shift_id INT PRIMARY KEY,
    employee_id INT,
    shift_type VARCHAR(50),
    start_time TIME,
    end_time TIME
);
-- --------------------------------------------------------------
-- 9) Benefits (benefit_id, employee_id, benefit_type, coverage_details)

CREATE TABLE Benefits (
    benefit_id INT PRIMARY KEY,
    employee_id INT,
    benefit_type VARCHAR(100),
    coverage_details VARCHAR(255)
);
-- ---------------------------------------------------------------
-- 10) PerformanceReviews (review_id, employee_id, reviewer_id, review_date, performance_rating, comments)

CREATE TABLE PerformanceReviews (
    review_id INT PRIMARY KEY,
    employee_id INT,
    reviewer_id INT,
    review_date DATE,
    performance_rating DECIMAL(3, 2),
    comments TEXT
);
-- ----------------------------------------------------------------





-- and foreign keys are -- Foreign Keys of all -- 

-- ----------------------------------------------------
ALTER TABLE Employees
ADD COLUMN welcome_message VARCHAR(50),
ADD CONSTRAINT FK_Department_Employees FOREIGN KEY (department_id) REFERENCES Department(department_id),
ADD CONSTRAINT FK_Positions_Employees FOREIGN KEY (position_id) REFERENCES Positions(position_id),
ADD CONSTRAINT FK_Salaries_Employees FOREIGN KEY (salary_id) REFERENCES Salaries(salary_id);
-- ---------------------------------------------------
-- ALTER TABLE Salaries
-- ADD CONSTRAINT FK_Employees_Salaries FOREIGN KEY (employee_id) REFERENCES Employees(employee_id);
-- ---------------------------------------------------
ALTER TABLE Attendance
ADD CONSTRAINT FK_Employees_Attendance FOREIGN KEY (employee_id) REFERENCES Employees(employee_id);
-- ---------------------------------------------------
ALTER TABLE Projects
ADD CONSTRAINT FK_Department_Projects FOREIGN KEY (department_id) REFERENCES Department(department_id);
-- ---------------------------------------------------
ALTER TABLE LeaveRequests
ADD CONSTRAINT FK_Employees_LeaveRequests FOREIGN KEY (employee_id) REFERENCES Employees(employee_id);
-- ---------------------------------------------------
ALTER TABLE Shifts
ADD CONSTRAINT FK_Employees_Shifts FOREIGN KEY (employee_id) REFERENCES Employees(employee_id);
-- ---------------------------------------------------
ALTER TABLE Benefits
ADD CONSTRAINT FK_Employees_Benefits FOREIGN KEY (employee_id) REFERENCES Employees(employee_id);
-- ---------------------------------------------------
ALTER TABLE PerformanceReviews
ADD CONSTRAINT FK_Employees_PerformanceReviews FOREIGN KEY (employee_id) REFERENCES Employees(employee_id);
-- ---------------------------------------------------  
-- modify
ALTER TABLE Projects
MODIFY COLUMN project_id VARCHAR(20);

Alter Table leaverequests
Modify column request_id varchar(20);
------------------------------------------------------

-- Insertion

INSERT INTO Employees (employee_id, name, department_id, position_id, salary_id) VALUES
(1, 'John Doe', 1, 1001, 1),
(2, 'Jane Smith', 2, 1002, 2),
(3, 'Michael Johnson', 3, 1003, 3),
(4, NULL, 4, 1001, 4),
(5, 'David Wilson', 5, 1002, 5),
(6, NULL, 6, 1003, 6),
(7, 'Christopher Lee', 7, 1004, 7),
(8, 'Amanda White', 8, 1001, 8),
(9, 'Matthew Harris', 9, 1002, 9),
(10, 'Jennifer Martin', 10, 1003, 10),
(11, 'Daniel Taylor', 1, 1004, 11),
(12, NULL, 2, 1001, 12),
(13, 'Andrew Thompson', 3, 1002, 13),
(14, NULL, 4, 1003, 14),
(15, 'Joshua Robinson', 5, 1004, 15),
(16, 'Samantha Lewis', 6, 1001, 16),
(17, 'Ryan Walker', 7, 1002, 17),
(18, 'Lauren Hall', 8, 1003, 18),
(19, 'Kevin Young', 9, 1004, 19),
(20, 'Maria Allen', 10, 1001, 20),
(21, 'William King', 1, 1002, 21),
(22, 'Sophia Wright', 2, 1003, 22),
(23, NULL, 3, 1004, 23),
(24, 'Olivia Adams', 4, 1001, 24),
(25, 'Alexander Baker', 5, 1002, 25),
(26, NULL, 6, 1003, 26),
(27, 'Mason Nelson', 7, 1004, 27),
(28, 'Amelia Carter', 8, 1001, 28),
(29, 'Ethan Perez', 9, 1002, 29),
(30, 'Charlotte Turner', 10, 1003, 30),
(31, 'Liam Roberts', 1, 1004, 31),
(32, 'Ava Phillips', 2, 1001, 32),
(33, NULL, 3, 1002, 33),
(34, 'Mia Parker', 4, 1003, 34),
(35, 'Lucas Edwards', 5, 1004, 35),
(36, NULL, 6, 1001, 36),
(37, 'Jackson Stewart', 7, 1002, 37),
(38, 'Evelyn Morris', 8, 1003, 38),
(39, NULL, 9, 1004, 39),
(40, 'Avery Hill', 10, 1001, 40);
---------------------------------------------
INSERT INTO Department (department_id, department_name) VALUES
(1, 'Engineering'),
(2, 'Sales'),
(3, 'Human Resources'),
(4, 'Finance'),
(5, 'Marketing'),
(6, 'Customer Support'),
(7, 'Research and Development'),
(8, 'Operations'),
(9, 'Quality Assurance'),
(10, 'Administration'),
(11, 'Information Technology'),
(12, 'Accounting'),
(13, 'Public Relations'),
(14, 'Legal'),
(15, 'Product Management'),
(16, 'Business Development'),
(17, 'Supply Chain'),
(18, 'Logistics'),
(19, 'Procurement'),
(20, 'Distribution'),
(21, 'Warehouse'),
(22, 'Facilities'),
(23, 'Maintenance'),
(24, 'Security'),
(25, 'Health and Safety'),
(26, 'Training and Development'),
(27, 'Compliance'),
(28, 'Legal Affairs'),
(29, 'Internal Audit'),
(30, 'Risk Management'),
(31, 'Corporate Communications'),
(32, 'Corporate Social Responsibility'),
(33, 'Investor Relations'),
(34, 'Corporate Strategy'),
(35, 'Corporate Development'),
(36, 'Mergers and Acquisitions'),
(37, 'Strategic Planning'),
(38, 'Financial Planning and Analysis'),
(39, 'Corporate Finance'),
(40, 'Treasury');
------------------------------------------------------
INSERT INTO Positions (position_id, position_title) VALUES
(1001, 'Software Engineer'),
(1002, 'Sales Representative'),
(1003, 'HR Specialist'),
(1004, 'Financial Analyst'),
(1005, 'Marketing Coordinator'),
(1006, 'Customer Support Specialist'),
(1007, 'Research Scientist'),
(1008, 'Operations Manager'),
(1009, 'QA Engineer'),
(1010, 'Administrator'),
(1011, 'Network Engineer'),
(1012, 'Business Analyst'),
(1013, 'Account Executive'),
(1014, 'Recruiter'),
(1015, 'Legal Counsel'),
(1016, 'Product Manager'),
(1017, 'Project Manager'),
(1018, 'Supply Chain Manager'),
(1019, 'Logistics Coordinator'),
(1020, 'Procurement Specialist'),
(1021, 'Warehouse Supervisor'),
(1022, 'Facilities Manager'),
(1023, 'Maintenance Technician'),
(1024, 'Security Officer'),
(1025, 'Safety Coordinator'),
(1026, 'Trainer'),
(1027, 'Compliance Officer'),
(1028, 'Legal Advisor'),
(1029, 'Internal Auditor'),
(1030, 'Risk Analyst'),
(1031, 'Communications Manager'),
(1032, 'CSR Specialist'),
(1033, 'Investor Relations Manager'),
(1034, 'Strategy Consultant'),
(1035, 'Corporate Development Manager'),
(1036, 'M&A Specialist'),
(1037, 'Strategic Planner'),
(1038, 'Financial Analyst'),
(1039, 'Finance Manager'),
(1040, 'Treasurer'),
(1041, 'M&A Specialist'),
(1042, 'Customer Support Specialist'),
(1043, 'Business Analyst'),
(1044, 'Logistics Coordinator'),
(1045, 'Financial Analyst');
-------------------------------------------------------------

INSERT INTO Salaries (salary_id, employee_id, amount, effective_date) VALUES
(1, 1, 60000.00, '2024-01-01'),
(2, 2, 55000.00, '2024-01-01'),
(3, 3, 65000.00, '2024-01-01'),
(4, 4, 62000.00, '2024-01-01'),
(5, 5, 58000.00, '2024-01-01'),
(6, 6, 70000.00, '2024-01-01'),
(7, 7, 75000.00, '2024-01-01'),
(8, 8, 62000.00, '2024-01-01'),
(9, 9, 60000.00, '2024-01-01'),
(10, 10, 55000.00, '2024-01-01'),
(11, 11, 78000.00, '2024-01-01'),
(12, 12, 63000.00, '2024-01-01'),
(13, 13, 65000.00, '2024-01-01'),
(14, 14, 62000.00, '2024-01-01'),
(15, 15, 58000.00, '2024-01-01'),
(16, 16, 70000.00, '2024-01-01'),
(17, 17, 75000.00, '2024-01-01'),
(18, 18, 62000.00, '2024-01-01'),
(19, 19, 60000.00, '2024-01-01'),
(20, 20, 55000.00, '2024-01-01'),
(21, 21, 78000.00, '2024-01-01'),
(22, 22, 63000.00, '2024-01-01'),
(23, 23, 65000.00, '2024-01-01'),
(24, 24, 62000.00, '2024-01-01'),
(25, 25, 58000.00, '2024-01-01'),
(26, 26, 70000.00, '2024-01-01'),
(27, 27, 75000.00, '2024-01-01'),
(28, 28, 62000.00, '2024-01-01'),
(29, 29, 60000.00, '2024-01-01'),
(30, 30, 55000.00, '2024-01-01'),
(31, 31, 78000.00, '2024-01-01'),
(32, 32, 63000.00, '2024-01-01'),
(33, 33, 65000.00, '2024-01-01'),
(34, 34, 62000.00, '2024-01-01'),
(35, 35, 58000.00, '2024-01-01'),
(36, 36, 70000.00, '2024-01-01'),
(37, 37, 75000.00, '2024-01-01'),
(38, 38, 62000.00, '2024-01-01'),
(39, 39, 60000.00, '2024-01-01'),
(40, 40, 55000.00, '2024-01-01');
-------------------------------------------------
INSERT INTO Attendance (attendance_id, employee_id, date, time_in, time_out) VALUES
(1, 1, '2024-05-01', '09:00:00', '17:00:00'),
(2, 2, '2024-05-01', '08:30:00', '16:30:00'),
(3, 3, '2024-05-01', '08:45:00', '17:15:00'),
(4, 4, '2024-05-01', '09:15:00', '17:30:00'),
(5, 5, '2024-05-01', '09:30:00', '17:30:00'),
(6, 6, '2024-05-01', '08:00:00', '16:00:00'),
(7, 7, '2024-05-01', '08:30:00', '17:30:00'),
(8, 8, '2024-05-01', '09:00:00', '17:00:00'),
(9, 9, '2024-05-01', '08:45:00', '17:15:00'),
(10, 10, '2024-05-01', '08:30:00', '17:30:00'),
(11, 11, '2024-05-01', '09:00:00', '17:00:00'),
(12, 12, '2024-05-01', '09:00:00', '17:00:00'),
(13, 13, '2024-05-01', '08:30:00', '17:30:00'),
(14, 14, '2024-05-01', '09:00:00', '17:00:00'),
(15, 15, '2024-05-01', '08:45:00', '17:15:00'),
(16, 16, '2024-05-01', '08:30:00', '17:30:00'),
(17, 17, '2024-05-01', '09:00:00', '17:00:00'),
(18, 18, '2024-05-01', '08:30:00', '17:30:00'),
(19, 19, '2024-05-01', '09:00:00', '17:00:00'),
(20, 20, '2024-05-01', '08:45:00', '17:15:00'),
(21, 21, '2024-05-01', '08:30:00', '17:30:00'),
(22, 22, '2024-05-01', '09:00:00', '17:00:00'),
(23, 23, '2024-05-01', '08:30:00', '17:30:00'),
(24, 24, '2024-05-01', '09:00:00', '17:00:00'),
(25, 25, '2024-05-01', '08:45:00', '17:15:00'),
(26, 26, '2024-05-01', '08:30:00', '17:30:00'),
(27, 27, '2024-05-01', '09:00:00', '17:00:00'),
(28, 28, '2024-05-01', '09:00:00', '17:00:00'),
(29, 29, '2024-05-01', '08:30:00', '17:30:00'),
(30, 30, '2024-05-01', '09:00:00', '17:00:00'),
(31, 31, '2024-05-01', '08:45:00', '17:15:00'),
(32, 32, '2024-05-01', '08:30:00', '17:30:00'),
(33, 33, '2024-05-01', '09:00:00', '17:00:00'),
(34, 34, '2024-05-01', '08:30:00', '17:30:00'),
(35, 35, '2024-05-01', '09:00:00', '17:00:00'),
(36, 36, '2024-05-01', '08:45:00', '17:15:00'),
(37, 37, '2024-05-01', '08:30:00', '17:30:00'),
(38, 38, '2024-05-01', '09:00:00', '17:00:00'),
(39, 39, '2024-05-01', '08:30:00', '17:30:00'),
(40, 40, '2024-05-01', '09:00:00', '17:00:00');
-- -------------------------------------------------------

INSERT INTO Projects (project_id, project_name, department_id) VALUES
('P041', 'Project Alpha', 1),
('P042', 'Project Beta', 2),
('P043', 'Project Gamma', 3),
('P044', 'Project Delta', 4),
('P045', 'Project Epsilon', 5),
('P046', 'Project Alpha', 6),
('P047', 'Project Beta', 7),
('P048', 'Project Gamma', 8),
('P049', 'Project Delta', 9),
('P050', 'Project Alpha', 10),
('P051', 'Project Alpha', 11),
('P052', 'Project Beta', 12),
('P053', 'Project Gamma', 13),
('P054', 'Project Delta', 14),
('P055', 'Project Epsilon', 15),
('P056', 'Project Alpha', 16),
('P057', 'Project Beta', 17),
('P058', 'Project Gamma', 18),
('P059', 'Project Delta', 19),
('P060', 'Project Alpha', 20),
('P061', 'Project Alpha', 21),
('P062', 'Project Beta', 22),
('P063', 'Project Gamma', 23),
('P064', 'Project Delta', 24),
('P065', 'Project Epsilon', 25),
('P066', 'Project Alpha', 26),
('P067', 'Project Beta', 27),
('P068', 'Project Gamma', 28),
('P069', 'Project Delta', 29),
('P070', 'Project Alpha', 30),
('P071', 'Project Alpha', 31),
('P072', 'Project Beta', 32),
('P073', 'Project Gamma', 33),
('P074', 'Project Delta', 34),
('P075', 'Project Epsilon', 35),
('P076', 'Project Alpha', 36),
('P077', 'Project Beta', 37),
('P078', 'Project Gamma', 38),
('P079', 'Project Delta', 39),
('P080', 'Project Alpha', 40);
-- ---------------------------------------------------
INSERT INTO LeaveRequests (request_id, employee_id, start_date, end_date, status) VALUES
('LR001', 1, '2024-04-01', '2024-04-05', 'Approved'),
('LR002', 2, '2024-04-10', '2024-04-15', 'Pending'),
('LR003', 3, '2024-04-20', '2024-04-25', 'Approved'),
('LR004', 4, '2024-04-03', '2024-04-08', 'Pending'),
('LR005', 5, '2024-04-12', '2024-04-17', 'Approved'),
('LR006', 6, '2024-04-23', '2024-04-28', 'Pending'),
('LR007', 7, '2024-04-05', '2024-04-10', 'Approved'),
('LR008', 8, '2024-04-15', '2024-04-20', 'Pending'),
('LR009', 9, '2024-04-25', '2024-04-30', 'Approved'),
('LR010', 10, '2024-04-08', '2024-04-13', 'Pending'),
('LR011', 11, '2024-04-17', '2024-04-22', 'Approved'),
('LR012', 12, '2024-04-28', '2024-05-03', 'Pending'),
('LR013', 13, '2024-04-01', '2024-04-06', 'Approved'),
('LR014', 14, '2024-04-10', '2024-04-15', 'Pending'),
('LR015', 15, '2024-04-20', '2024-04-25', 'Approved'),
('LR016', 16, '2024-04-03', '2024-04-08', 'Pending'),
('LR017', 17, '2024-04-12', '2024-04-17', 'Approved'),
('LR018', 18, '2024-04-23', '2024-04-28', 'Pending'),
('LR019', 19, '2024-04-05', '2024-04-10', 'Approved'),
('LR020', 20, '2024-04-15', '2024-04-20', 'Pending'),
('LR021', 21, '2024-04-25', '2024-04-30', 'Approved'),
('LR022', 22, '2024-04-08', '2024-04-13', 'Pending'),
('LR023', 23, '2024-04-17', '2024-04-22', 'Approved'),
('LR024', 24, '2024-04-28', '2024-05-03', 'Pending'),
('LR025', 25, '2024-04-01', '2024-04-06', 'Approved'),
('LR026', 26, '2024-04-10', '2024-04-15', 'Pending'),
('LR027', 27, '2024-04-20', '2024-04-25', 'Approved'),
('LR028', 28, '2024-04-03', '2024-04-08', 'Pending'),
('LR029', 29, '2024-04-12', '2024-04-17', 'Approved'),
('LR030', 30, '2024-04-23', '2024-04-28', 'Pending'),
('LR031', 31, '2024-04-05', '2024-04-10', 'Approved'),
('LR032', 32, '2024-04-15', '2024-04-20', 'Pending'),
('LR033', 33, '2024-04-25', '2024-04-30', 'Approved'),
('LR034', 34, '2024-04-08', '2024-04-13', 'Pending'),
('LR035', 35, '2024-04-17', '2024-04-22', 'Approved'),
('LR036', 36, '2024-04-28', '2024-05-03', 'Pending'),
('LR037', 37, '2024-04-01', '2024-04-06', 'Approved'),
('LR038', 38, '2024-04-10', '2024-04-15', 'Pending'),
('LR039', 39, '2024-04-20', '2024-04-25', 'Approved'),
('LR040', 40, '2024-04-03', '2024-04-08', 'Pending');
-- ---------------------------------------------------------
INSERT INTO Shifts (shift_id, employee_id, shift_type, start_time, end_time)
VALUES
    (101, 1, 'Morning', '08:00:00', '16:00:00'),
    (102, 2, 'Evening', '16:00:00', '00:00:00'),
    (103, 3, 'Night', '00:00:00', '08:00:00'),
    (104, 4, 'Morning', '08:00:00', '16:00:00'),
    (105, 5, 'Evening', '16:00:00', '00:00:00'),
    (106, 6, 'Night', '00:00:00', '08:00:00'),
    (107, 7, 'Morning', '08:00:00', '16:00:00'),
    (108, 8, 'Evening', '16:00:00', '00:00:00'),
    (109, 9, 'Night', '00:00:00', '08:00:00'),
    (110, 10, 'Morning', '08:00:00', '16:00:00'),
    (111, 11, 'Evening', '16:00:00', '00:00:00'),
    (112, 12, 'Night', '00:00:00', '08:00:00'),
    (113, 13, 'Morning', '08:00:00', '16:00:00'),
    (114, 14, 'Evening', '16:00:00', '00:00:00'),
    (115, 15, 'Night', '00:00:00', '08:00:00'),
    (116, 16, 'Morning', '08:00:00', '16:00:00'),
    (117, 17, 'Evening', '16:00:00', '00:00:00'),
    (118, 18, 'Night', '00:00:00', '08:00:00'),
    (119, 19, 'Morning', '08:00:00', '16:00:00'),
    (120, 20, 'Evening', '16:00:00', '00:00:00'),
    (121, 21, 'Night', '00:00:00', '08:00:00'),
    (122, 22, 'Morning', '08:00:00', '16:00:00'),
    (123, 23, 'Evening', '16:00:00', '00:00:00'),
    (124, 24, 'Night', '00:00:00', '08:00:00'),
    (125, 25, 'Morning', '08:00:00', '16:00:00'),
    (126, 26, 'Evening', '16:00:00', '00:00:00'),
    (127, 27, 'Night', '00:00:00', '08:00:00'),
    (128, 28, 'Morning', '08:00:00', '16:00:00'),
    (129, 29, 'Evening', '16:00:00', '00:00:00'),
    (130, 30, 'Night', '00:00:00', '08:00:00'),
    (131, 31, 'Morning', '08:00:00', '16:00:00'),
    (132, 32, 'Evening', '16:00:00', '00:00:00'),
    (133, 33, 'Night', '00:00:00', '08:00:00'),
    (134, 34, 'Morning', '08:00:00', '16:00:00'),
    (135, 35, 'Evening', '16:00:00', '00:00:00'),
    (136, 36, 'Night', '00:00:00', '08:00:00'),
    (137, 37, 'Morning', '08:00:00', '16:00:00'),
    (138, 38, 'Evening', '16:00:00', '00:00:00'),
    (139, 39, 'Night', '00:00:00', '08:00:00'),
    (140, 40, 'Morning', '08:00:00', '16:00:00');
------------------------------------------------------

INSERT INTO Benefits (benefit_id, employee_id, benefit_type, coverage_details)
VALUES
    (4001, 1, 'Health Insurance', 'Full coverage'),
    (4002, 2, 'Dental Insurance', 'Partial coverage'),
    (4003, 3, 'Retirement Plan', '401(k) matching'),
    (4004, 4, 'Paid Time Off', '10 days per year'),
    (4005, 5, 'Gym Membership', 'Discounted rates'),
    (4006, 6, 'Health Insurance', 'Full coverage'),
    (4007, 7, 'Dental Insurance', 'Partial coverage'),
    (4008, 8, 'Retirement Plan', '401(k) matching'),
    (4009, 9, 'Paid Time Off', '10 days per year'),
    (4010, 10, 'Gym Membership', 'Discounted rates'),
    (4011, 11, 'Health Insurance', 'Full coverage'),
    (4012, 12, 'Dental Insurance', 'Partial coverage'),
    (4013, 13, 'Retirement Plan', '401(k) matching'),
    (4014, 14, 'Paid Time Off', '10 days per year'),
    (4015, 15, 'Gym Membership', 'Discounted rates'),
    (4016, 16, 'Health Insurance', 'Full coverage'),
    (4017, 17, 'Dental Insurance', 'Partial coverage'),
    (4018, 18, 'Retirement Plan', '401(k) matching'),
    (4019, 19, 'Paid Time Off', '10 days per year'),
    (4020, 20, 'Gym Membership', 'Discounted rates'),
    (4021, 21, 'Health Insurance', 'Full coverage'),
    (4022, 22, 'Dental Insurance', 'Partial coverage'),
    (4023, 23, 'Retirement Plan', '401(k) matching'),
    (4024, 24, 'Paid Time Off', '10 days per year'),
    (4025, 25, 'Gym Membership', 'Discounted rates'),
    (4026, 26, 'Health Insurance', 'Full coverage'),
    (4027, 27, 'Dental Insurance', 'Partial coverage'),
    (4028, 28, 'Retirement Plan', '401(k) matching'),
    (4029, 29, 'Paid Time Off', '10 days per year'),
    (4030, 30, 'Gym Membership', 'Discounted rates'),
    (4031, 31, 'Health Insurance', 'Full coverage'),
    (4032, 32, 'Dental Insurance', 'Partial coverage'),
    (4033, 33, 'Retirement Plan', '401(k) matching'),
    (4034, 34, 'Paid Time Off', '10 days per year'),
    (4035, 35, 'Gym Membership', 'Discounted rates'),
    (4036, 36, 'Health Insurance', 'Full coverage'),
    (4037, 37, 'Dental Insurance', 'Partial coverage'),
    (4038, 38, 'Retirement Plan', '401(k) matching'),
    (4039, 39, 'Paid Time Off', '10 days per year'),
    (4040, 40, 'Gym Membership', 'Discounted rates');
-- ----------------------------------------------------
INSERT INTO PerformanceReviews (review_id, employee_id, reviewer_id, review_date, performance_rating, comments)
VALUES
    (101, 1, 1001, '2023-01-05', 4.50, 'Excellent performance overall'),
    (102, 2, 1002, '2023-02-10', 3.80, 'Good progress, areas for improvement identified'),
    (103, 3, 1003, '2023-03-15', 4.20, 'Consistently meets expectations'),
    (104, 4, 1004, '2023-04-20', 4.00, 'Satisfactory performance'),
    (105, 5, 1005, '2023-05-25', 4.70, 'Exceptional work, exceeding expectations'),
    (106, 6, 1006, '2023-06-30', 3.50, 'Inconsistent performance, improvement needed'),
    (107, 7, 1007, '2023-07-05', 4.00, 'Meeting expectations, room for growth identified'),
    (108, 8, 1008, '2023-08-10', 4.30, 'High-quality work, valuable contributions'),
    (109, 9, 1009, '2023-09-15', 3.90, 'Solid performance, with areas for development'),
    (110, 10, 1010, '2023-10-20', 4.60, 'Exceeding expectations consistently'),
    (111, 11, 1011, '2023-11-25', 3.70, 'Progress made, further development required'),
    (112, 12, 1012, '2023-12-30', 4.10, 'Meeting expectations, potential for growth noted'),
    (113, 13, 1013, '2024-01-05', 4.40, 'Consistent high performance'),
    (114, 14, 1014, '2024-02-10', 3.60, 'Areas for improvement identified, progress made'),
    (115, 15, 1015, '2024-03-15', 4.00, 'Meeting expectations, with room for advancement'),
    (116, 16, 1016, '2024-04-20', 4.80, 'Outstanding work, exceeding all goals'),
    (117, 17, 1017, '2024-05-25', 3.90, 'Overall satisfactory performance, with potential for growth'),
    (118, 18, 1018, '2024-06-30', 4.20, 'Good performance, improvements noted'),
    (119, 19, 1019, '2024-07-05', 4.50, 'Exceptional achievements, consistently high quality'),
    (120, 20, 1020, '2024-08-10', 3.80, 'Solid performance, with some areas for development'),
    (121, 21, 1021, '2024-09-15', 4.30, 'Consistently meets expectations, with room for advancement'),
    (122, 22, 1022, '2024-10-20', 4.10, 'Satisfactory performance, with notable contributions'),
    (123, 23, 1023, '2024-11-25', 4.70, 'Exemplary work, consistently exceeds expectations'),
    (124, 24, 1024, '2024-12-30', 3.90, 'Meeting expectations overall, with areas for growth'),
    (125, 25, 1025, '2025-01-05', 4.40, 'High-quality performance, valuable contributions'),
    (126, 26, 1026, '2025-02-10', 3.60, 'Progress made, further improvements needed'),
    (127, 27, 1027, '2025-03-15', 4.00, 'Meeting expectations, with potential for growth'),
    (128, 28, 1028, '2025-04-20', 4.80, 'Consistently outstanding work, exceeds all goals'),
    (129, 29, 1029, '2025-05-25', 3.90, 'Solid performance, with opportunities for development'),
    (130, 30, 1030, '2025-06-30', 4.20, 'Good performance, with notable achievements'),
    (131, 31, 1031, '2025-07-05', 4.50, 'Exemplary achievements, consistently high quality work'),
    (132, 32, 1032, '2025-08-10', 3.80, 'Meeting expectations, with room for improvement'),
    (133, 33, 1033, '2025-09-15', 4.30, 'Consistent high-quality work, valuable contributions'),
    (134, 34, 1034, '2025-10-20', 4.10, 'Satisfactory performance, with areas for development'),
    (135, 35, 1035, '2025-11-25', 4.70, 'Exceptional work, consistently exceeds expectations'),
    (136, 36, 1036, '2025-12-30', 3.90, 'Meeting expectations overall, with room for growth'),
    (137, 37, 1037, '2026-01-05', 4.40, 'Solid performance, with potential for advancement'),
    (138, 38, 1038, '2026-02-10', 3.60, 'Good progress made, areas for further development identified'),
    (139, 39, 1039, '2026-03-15', 4.00, 'Meeting expectations, with room for improvement'),
    (140, 40, 1040, '2026-04-20', 4.80, 'Outstanding achievements, consistently exceeds all goals');
--------- ---------------------------------------------------------------------------------

DELIMITER //
-- TO add an employee
CREATE PROCEDURE AddEmployee (
    IN emp_id INT,
    IN emp_name VARCHAR(255),
    IN dept_id INT,
    IN pos_id INT,
    IN sal_id INT
)
BEGIN
    INSERT INTO Employees (employee_id, name, department_id, position_id, salary_id)
    VALUES (emp_id, emp_name, dept_id, pos_id, sal_id);
END //

DELIMITER ;

CALL AddEmployee(111, 'JAHANZAIB HASSAN', 101, 201, 301);

DELIMITER //
CREATE TRIGGER before_insert_employee
BEFORE INSERT ON Employees
FOR EACH ROW
BEGIN
    SET NEW.welcome_message = CONCAT('Welcome ', NEW.name, ' to the company!');
END //
DELIMITER ;

select *from Employees;


-- ------------------------------------------------------------------------

DELIMITER //

CREATE PROCEDURE UpdateEmployeeDepartment (
    emp_id INT,
    new_dept_id INT
)
BEGIN
    UPDATE Employees
    SET department_id = new_dept_id
    WHERE employee_id = emp_id;
END //

CREATE PROCEDURE RemoveEmployee (
    emp_id INT
)
BEGIN
    DELETE FROM Employees
    WHERE employee_id = emp_id;
END //

CREATE FUNCTION GetEmployeeSalary (
    emp_id INT
)
RETURNS DECIMAL(10, 2)
DETERMINISTIC
BEGIN
    DECLARE emp_salary DECIMAL(10, 2);
    SELECT s.amount INTO emp_salary
    FROM Salaries s
    JOIN Employees e ON s.salary_id = e.salary_id
    WHERE e.employee_id = emp_id;
    RETURN emp_salary;
END //

CREATE PROCEDURE AddProject (
    proj_id VARCHAR(10),
    proj_name VARCHAR(255),
    dept_id INT
)
BEGIN
    INSERT INTO Projects (project_id, project_name, department_id)
    VALUES (proj_id, proj_name, dept_id);
END //

DELIMITER ;

drop procedure UpdateEmployeeDepartment;
drop procedure RemoveEmployee;
CALL UpdateEmployeeDepartment(1, 101);

CALL RemoveEmployee(1);

SELECT GetEmployeeSalary(10);

CALL AddProject('PROJ001', 'New Project', 101);

SELECT *FROM Projects ;